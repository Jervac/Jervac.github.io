package com.dodgy.core;

public interface AdHandler {

    public void showAds(boolean show);
}