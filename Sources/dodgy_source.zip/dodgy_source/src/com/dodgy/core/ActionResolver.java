package com.dodgy.core;

public interface ActionResolver {
    public void showOrLoadInterstitial();
}
