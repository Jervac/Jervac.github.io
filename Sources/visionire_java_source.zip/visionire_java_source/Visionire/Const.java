package Visionire;

public class Const {
	public final static int MAGIC_NUMBER = 1313131313;
	public final static int PORT = 6510;
}