package Visionire.storage;

/**
 *
 * @author nickbabenko
 */
public class DatabaseHandler { }