package Visionire.Framework.Network;

public class Socket {
}
