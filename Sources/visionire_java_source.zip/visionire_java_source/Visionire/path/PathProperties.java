package Visionire.path;

/**
 *
 * @author nickbabenko
 */
public class PathProperties {
    public static double SPEED = 0.0015;
}
