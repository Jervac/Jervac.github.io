package bagel.util;

public class util {

}
