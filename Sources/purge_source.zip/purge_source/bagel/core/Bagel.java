package bagel.core;

import bagel.rendering.Graphics;

public abstract class Bagel {

    public static Graphics graphics;

    public static int TILESIZE;

    public static boolean debugging = false;
    
    public void poop() {
    	System.out.println("it works");
    }

}
