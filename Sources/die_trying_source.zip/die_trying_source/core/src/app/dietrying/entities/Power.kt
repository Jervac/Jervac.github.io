package killerspacewreck.entities

enum class Power(val duration: Float) {
    SECOND_PLAYER(10f),
    SHIELD(10f) // kek
}