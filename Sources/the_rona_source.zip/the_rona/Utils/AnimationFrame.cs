﻿using System;
using Microsoft.Xna.Framework;

namespace the_rona.Utils {
	public class AnimationFrame {
		public Rectangle SourceRectangle { get; set; }
		public TimeSpan Duration { get; set; }
	}
}